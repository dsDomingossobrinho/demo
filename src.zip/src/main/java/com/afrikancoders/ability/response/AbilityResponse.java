package com.afrikancoders.ability.response;

public record AbilityResponse(
       long id,
       String ability
) {
}

package com.afrikancoders.ability.dto;

public record AbilityDto(
        String ability
) {
}

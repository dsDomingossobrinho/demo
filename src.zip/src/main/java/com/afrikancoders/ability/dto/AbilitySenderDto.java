package com.afrikancoders.ability.dto;

public record AbilitySenderDto(
    long id
    ) {
}

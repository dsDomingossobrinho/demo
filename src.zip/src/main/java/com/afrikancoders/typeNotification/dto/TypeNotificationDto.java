package com.afrikancoders.typeNotification.dto;

public record TypeNotificationDto(
        String type
) {
}

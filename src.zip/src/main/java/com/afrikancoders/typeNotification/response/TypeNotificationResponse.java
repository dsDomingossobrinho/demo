package com.afrikancoders.typeNotification.response;

public record TypeNotificationResponse(
       long id,
       String type
) {
}

package com.afrikancoders.collaboratorSpeciality.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.afrikancoders.collaboratorSpeciality.entity.CollaboratorSpecialitys;

public interface CollaboratorSpecialityRepository extends JpaRepository<CollaboratorSpecialitys, Long> {
    
}

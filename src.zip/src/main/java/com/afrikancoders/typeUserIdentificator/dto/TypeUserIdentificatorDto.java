package com.afrikancoders.typeUserIdentificator.dto;

public record TypeUserIdentificatorDto(
        String type
) {
}

package com.afrikancoders.typeUserIdentificator.dto;

public record TypeUserIdentificatorSenderDto(
    long id
    ) {
}

package com.afrikancoders.typeUserIdentificator.response;

public record TypeUserIdentificatorResponse(
       long id,
       String type
) {
}

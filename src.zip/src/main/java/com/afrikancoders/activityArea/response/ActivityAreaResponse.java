package com.afrikancoders.activityArea.response;

public record ActivityAreaResponse(
       long id,
       String activityArea
) {
}

package com.afrikancoders.activityArea.dto;

public record ActivityAreaSenderDto(
    long id
    ) {
}

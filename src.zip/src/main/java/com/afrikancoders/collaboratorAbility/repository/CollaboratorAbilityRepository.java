package com.afrikancoders.collaboratorAbility.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.afrikancoders.collaboratorAbility.entity.CollaboratorAbilitys;

public interface CollaboratorAbilityRepository extends JpaRepository<CollaboratorAbilitys, Long> {
    
}

package com.afrikancoders.speciality.response;

public record SpecialityResponse(
       long id,
       String speciality
) {
}

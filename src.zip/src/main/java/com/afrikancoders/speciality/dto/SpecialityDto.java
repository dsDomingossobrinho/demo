package com.afrikancoders.speciality.dto;

public record SpecialityDto(
        String speciality
) {
}

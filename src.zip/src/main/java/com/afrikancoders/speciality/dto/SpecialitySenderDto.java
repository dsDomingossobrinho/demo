package com.afrikancoders.speciality.dto;

public record SpecialitySenderDto(
    long id
    ) {
}

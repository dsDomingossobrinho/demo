package com.afrikancoders.role.response;

public record RoleResponse(
       long id,
       String role
) {
}

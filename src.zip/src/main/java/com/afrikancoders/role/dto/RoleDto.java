package com.afrikancoders.role.dto;

public record RoleDto(
        String role
) {
}

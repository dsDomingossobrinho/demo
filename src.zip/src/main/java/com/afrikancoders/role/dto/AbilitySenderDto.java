package com.afrikancoders.role.dto;

public record AbilitySenderDto(
    long id
    ) {
}

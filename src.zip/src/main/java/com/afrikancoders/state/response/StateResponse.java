package com.afrikancoders.state.response;

public record StateResponse(
       long id,
       String state
) {
}

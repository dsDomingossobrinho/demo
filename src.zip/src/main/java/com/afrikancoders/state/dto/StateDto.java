package com.afrikancoders.state.dto;

public record StateDto(
        String state
) {
}

package com.afrikancoders.state.dto;

public record StateSenderDto(
    long id
    ) {
}

package com.afrikancoders.evaluationCriteriaAndEvaluation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.afrikancoders.evaluationCriteriaAndEvaluation.entity.EvaluationCriteriaAndEvaluations;

public interface EvaluationCriteriaAndEvaluationRepository extends JpaRepository<EvaluationCriteriaAndEvaluations, Long> {
    
}

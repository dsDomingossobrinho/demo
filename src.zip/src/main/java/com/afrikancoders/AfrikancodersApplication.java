package com.afrikancoders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AfrikancodersApplication {

	public static void main(String[] args) {
		SpringApplication.run(AfrikancodersApplication.class, args);
	}

}

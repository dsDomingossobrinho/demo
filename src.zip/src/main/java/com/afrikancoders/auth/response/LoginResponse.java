package com.afrikancoders.auth.response;

public record LoginResponse (
        String token
) {
}

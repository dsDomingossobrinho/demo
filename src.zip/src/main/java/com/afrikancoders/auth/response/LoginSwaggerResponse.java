package com.afrikancoders.auth.response;

public record LoginSwaggerResponse (
    String token
) {
}



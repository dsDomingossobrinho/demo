package com.afrikancoders.auth.dtos;

public record LoginDto(
        String email,
        String password
) {
}

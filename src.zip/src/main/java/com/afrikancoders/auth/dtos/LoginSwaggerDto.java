package com.afrikancoders.auth.dtos;

public record LoginSwaggerDto(

String username,
String password

) {
}
